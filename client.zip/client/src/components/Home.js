import React from 'react'

export default function Home() {
    return (
        <div className="container">
            <blockquote>
                <h6>if it works dont touch it</h6>
                <p className="right-align">~ram</p>
            </blockquote>
            <blockquote>
                <h6>if it works dont touch it</h6>
                <p className="right-align">~ram</p>
            </blockquote>
        </div>
    )
}
