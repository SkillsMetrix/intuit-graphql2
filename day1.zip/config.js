


export const MONGO_URI='mongodb+srv://intuit:intuit@cluster0.rle5i.mongodb.net/intuit?retryWrites=true&w=majority&appName=Cluster0'