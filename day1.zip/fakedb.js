export const users = [
  {
    id: "23131",
    firstName: "suresh",
    lastName: "kumar",
    email: "suresh@mail.com",
    password: "pass@123",
  },
  {
    id: "23132",
    firstName: "Adam",
    lastName: "lukas",
    email: "adam@mail.com",
    password: "pass@1234",
  },
];

export const quotes = [
  {
    name: "i love coffee anytime",
    by: "23131",
  },
  {
    name: "this is anothe quote",
    by: "23131",
  },
  {
    name: "love going out with friends",
    by: "23132",
  },
];
